# lhw-send-email
使用 pip install lhw-send-email 进行下载该库<br>
本库是作者第一个自主发布的三方库<br>

# 开发目的
为了完善自主开发的网站的验证码机制而做出的尝试

# 基本用法
